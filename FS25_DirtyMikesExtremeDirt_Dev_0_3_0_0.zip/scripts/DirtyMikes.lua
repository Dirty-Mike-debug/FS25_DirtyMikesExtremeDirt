-- Dirty Mike's Extreme Dirt
-- Farming Simulator 25
-- Development Version 0.3.0.0
--
-- Changes in 0.3.0.0: rain cleaning (1% per 10/5/3 min by rainfall, none under
-- cover; cover = raycast upward). Multipliers unchanged.
-- Changes in 0.2.0.4: fixed debug-line crash ("probe" was declared after use).
-- Changes in 0.2.0.3: fixed nil "probe" error in debug line (declared after use).
-- Changes in 0.2.0.3: override now installs at file load (0.2.0.2 log
-- proved the loadMap install was never called). Adds a 60s CHECK log line.
-- Changes in 0.2.0.2 (diagnostic build, multipliers unchanged):
--   * Throttled debug output for the vehicle you are driving, including
--     rain and dirt-amount readings, to prepare rain cleaning.
--   * One-time API probe at map load. Set DirtyMikes.DEBUG = false to silence.
--
-- Multipliers (unchanged from 0.2.0.1):
--   Dry road / off-field: 0x    Dry field: 4x    Damp: 6x
--   Wet field: 10x              Extremely muddy: 12x

DirtyMikes = {}
DirtyMikes.MOD_NAME = "Dirty Mike's Extreme Dirt"
DirtyMikes.VERSION = "0.3.0.0"
DirtyMikes.DEBUG = true
DirtyMikes.DEBUG_INTERVAL_MS = 5000
DirtyMikes.lastDebugTime = 0
DirtyMikes.overrideCallCount = 0

DirtyMikes.DIRT_MULTIPLIERS = {
    ROAD = 0,
    DRY_FIELD = 4,
    DAMP_FIELD = 6,
    WET_FIELD = 10,
    EXTREMELY_MUDDY_FIELD = 12
}

DirtyMikes.WETNESS_THRESHOLDS = {
    DAMP_MAX = 0.25,
    WET_MAX = 0.625
}

local function log(fmt, ...)
    print(string.format("[%s] " .. fmt, DirtyMikes.MOD_NAME, ...))
end

-- Returns isOnField, and a label for where the value came from.
-- Safe method call: returns value or "n/a"
local function probe(obj, name)
    if obj == nil or obj[name] == nil then return "n/a" end
    local ok, v = pcall(obj[name], obj)
    if not ok then return "err" end
    return v
end

function DirtyMikes.readIsOnField(vehicle)
    if vehicle.getIsOnField ~= nil then
        return vehicle:getIsOnField() == true, "getIsOnField()"
    elseif vehicle.isOnField ~= nil then
        return vehicle.isOnField == true, "isOnField"
    end
    return false, "NOT FOUND"
end

function DirtyMikes.readWetness()
    local mission = g_currentMission
    if mission ~= nil and mission.environment ~= nil
        and mission.environment.weather ~= nil
        and mission.environment.weather.getGroundWetness ~= nil then
        return mission.environment.weather:getGroundWetness() or 0
    end
    return 0
end

function DirtyMikes.getTargetBaseDirtMultiplier(vehicle)
    local speed = 0
    if vehicle.getLastSpeed ~= nil then
        speed = vehicle:getLastSpeed()
    end
    local onField, fieldSource = DirtyMikes.readIsOnField(vehicle)
    local wetness = DirtyMikes.readWetness()

    local target
    if speed < 1 then
        target = 0
    elseif not onField then
        target = DirtyMikes.DIRT_MULTIPLIERS.ROAD
    elseif wetness <= 0 then
        target = DirtyMikes.DIRT_MULTIPLIERS.DRY_FIELD
    elseif wetness <= DirtyMikes.WETNESS_THRESHOLDS.DAMP_MAX then
        target = DirtyMikes.DIRT_MULTIPLIERS.DAMP_FIELD
    elseif wetness <= DirtyMikes.WETNESS_THRESHOLDS.WET_MAX then
        target = DirtyMikes.DIRT_MULTIPLIERS.WET_FIELD
    else
        target = DirtyMikes.DIRT_MULTIPLIERS.EXTREMELY_MUDDY_FIELD
    end

    return target, speed, onField, fieldSource, wetness
end

-- ---------------------------------------------------------------------
-- Rain cleaning (0.3.0.0)
--   Uncovered vehicles lose 1% dirt every N minutes while it rains:
--     light rain  (rain scale <= 0.33): every 10 min
--     medium rain (<= 0.66):            every 5 min
--     heavy rain  (> 0.66):             every 3 min
--   Vehicles with something solid overhead (shed, roof) are not cleaned.
-- ---------------------------------------------------------------------
DirtyMikes.RAIN = {
    ENABLED = true,
    MIN_RAIN = 0.01,
    LIGHT_MAX = 0.33,
    MEDIUM_MAX = 0.66,
    STEP = 0.01,               -- 1% dirt
    LIGHT_MINUTES = 10,
    MEDIUM_MINUTES = 5,
    HEAVY_MINUTES = 3,
    APPLY_THRESHOLD = 0.002,   -- apply cleaning in chunks of 0.2%
    MAX_DT_MS = 5000,          -- ignore larger gaps between calls
    COVER_RAY_LENGTH = 15,     -- metres checked above the vehicle
    COVER_CACHE_MS = 5000,
    MAX_LOG_LINES = 60
}
DirtyMikes.rainLogLines = 0

function DirtyMikes.getRainIntervalMinutes(rain)
    local r = DirtyMikes.RAIN
    if rain <= r.MIN_RAIN then
        return nil
    elseif rain <= r.LIGHT_MAX then
        return r.LIGHT_MINUTES
    elseif rain <= r.MEDIUM_MAX then
        return r.MEDIUM_MINUTES
    end
    return r.HEAVY_MINUTES
end

-- Raycast callback (called by the engine with the object that was hit)
function DirtyMikes:coverRayCallback(hitObjectId, x, y, z, distance)
    if hitObjectId ~= nil and hitObjectId ~= 0 then
        self.coverHit = true
        self.coverHitDistance = distance
    end
    return false
end

-- Returns covered (bool), source label
function DirtyMikes.isVehicleCovered(vehicle)
    local r = DirtyMikes.RAIN
    local now = g_time or 0
    if vehicle.dmCoverTime ~= nil and now - vehicle.dmCoverTime < r.COVER_CACHE_MS then
        return vehicle.dmCovered, "cached"
    end

    local covered, source = false, "no raycast available"
    if raycastClosest ~= nil and getWorldTranslation ~= nil and vehicle.rootNode ~= nil
        and CollisionFlag ~= nil then
        local mask = 0
        for _, name in ipairs({"STATIC_OBJECT", "BUILDING"}) do
            if CollisionFlag[name] ~= nil then
                mask = mask + CollisionFlag[name]
            end
        end
        if mask > 0 then
            local x, y, z = getWorldTranslation(vehicle.rootNode)
            local height = 3
            if vehicle.size ~= nil and vehicle.size.height ~= nil then
                height = vehicle.size.height
            end
            DirtyMikes.coverHit = false
            DirtyMikes.coverHitDistance = nil
            local ok, err = pcall(raycastClosest, x, y + height + 0.3, z, 0, 1, 0,
                "coverRayCallback", r.COVER_RAY_LENGTH, DirtyMikes, mask)
            if ok then
                covered = DirtyMikes.coverHit == true
                source = covered and string.format("hit at %.1fm", DirtyMikes.coverHitDistance or -1) or "clear sky"
            else
                source = "raycast error: " .. tostring(err)
            end
        end
    end

    vehicle.dmCovered = covered
    vehicle.dmCoverTime = now
    return covered, source
end

function DirtyMikes.applyRainCleaning(vehicle)
    local r = DirtyMikes.RAIN
    if not r.ENABLED or g_time == nil or vehicle.getDirtAmount == nil then
        return
    end

    local last = vehicle.dmRainLastTime
    vehicle.dmRainLastTime = g_time
    if last == nil then return end
    local dt = g_time - last
    if dt <= 0 then return end
    if dt > r.MAX_DT_MS then dt = r.MAX_DT_MS end

    local mission = g_currentMission
    local weather = mission and mission.environment and mission.environment.weather
    if weather == nil or weather.getRainFallScale == nil then return end

    local rain = weather:getRainFallScale() or 0
    local minutes = DirtyMikes.getRainIntervalMinutes(rain)
    if minutes == nil then
        vehicle.dmRainPending = 0
        return
    end

    vehicle.dmRainPending = (vehicle.dmRainPending or 0) + dt * (r.STEP / (minutes * 60000))
    if vehicle.dmRainPending < r.APPLY_THRESHOLD then return end

    local amount = vehicle.dmRainPending
    vehicle.dmRainPending = 0

    local dirtBefore = vehicle:getDirtAmount()
    if dirtBefore == nil or dirtBefore <= 0 then return end

    local covered, source = DirtyMikes.isVehicleCovered(vehicle)
    local applied = false
    if not covered then
        if vehicle.addDirtAmount ~= nil then
            vehicle:addDirtAmount(-math.min(amount, dirtBefore))
            applied = true
        elseif DirtyMikes.DEBUG and DirtyMikes.rainLogLines < r.MAX_LOG_LINES then
            DirtyMikes.rainLogLines = DirtyMikes.rainLogLines + 1
            log("RAIN: vehicle has no addDirtAmount(); cannot clean.")
        end
    end

    if DirtyMikes.DEBUG and DirtyMikes.rainLogLines < r.MAX_LOG_LINES then
        DirtyMikes.rainLogLines = DirtyMikes.rainLogLines + 1
        local name = (vehicle.getName ~= nil and vehicle:getName()) or "vehicle"
        log("RAIN %s rain=%.2f every=%dmin covered=%s (%s) applied=%s dirt %.4f -> %.4f",
            tostring(name), rain, minutes, tostring(covered), source, tostring(applied),
            dirtBefore, vehicle:getDirtAmount() or -1)
    end
end

-- Called as: newFunc(vehicle, superFunc) via Utils.overwrittenFunction
function DirtyMikes.getDirtMultiplier(vehicle, superFunc)
    local combined = superFunc(vehicle)
    local original = DirtyMikes.originalWashableGetDirtMultiplier(vehicle)
    local target, speed, onField, fieldSource, wetness = DirtyMikes.getTargetBaseDirtMultiplier(vehicle)
    local result = combined + target - original

    DirtyMikes.overrideCallCount = DirtyMikes.overrideCallCount + 1

    local okRain, errRain = pcall(DirtyMikes.applyRainCleaning, vehicle)
    if not okRain and not DirtyMikes.rainErrorLogged then
        DirtyMikes.rainErrorLogged = true
        log("ERROR in rain cleaning: %s", tostring(errRain))
    end

    if DirtyMikes.DEBUG and g_time ~= nil
        and vehicle.getIsControlled ~= nil and vehicle:getIsControlled()
        and g_time - DirtyMikes.lastDebugTime >= DirtyMikes.DEBUG_INTERVAL_MS then
        DirtyMikes.lastDebugTime = g_time
        local w = g_currentMission and g_currentMission.environment and g_currentMission.environment.weather
        log("DEBUG speed=%.1f km/h onField=%s (via %s) wetness=%.3f rain=%s dirt=%s | vanilla=%.2f target=%.2f combined=%.2f -> result=%.2f | calls=%d",
            speed, tostring(onField), fieldSource, wetness, tostring(probe(w, "getRainFallScale")),
            tostring(probe(vehicle, "getDirtAmount")), original, target, combined, result,
            DirtyMikes.overrideCallCount)
    end

    return result
end

function DirtyMikes:probeApi()
    if not DirtyMikes.DEBUG then return end
    local env = g_currentMission and g_currentMission.environment
    local w = env and env.weather
    log("PROBE weather=%s getRainFallScale=%s getGroundWetness=%s",
        tostring(w ~= nil), tostring(w ~= nil and w.getRainFallScale ~= nil), tostring(w ~= nil and w.getGroundWetness ~= nil))
    log("PROBE addDirtAmount=%s raycastClosest=%s CollisionFlag=%s STATIC_OBJECT=%s BUILDING=%s",
        tostring(Washable ~= nil and Washable.addDirtAmount ~= nil), tostring(raycastClosest ~= nil),
        tostring(CollisionFlag ~= nil), tostring(CollisionFlag ~= nil and CollisionFlag.STATIC_OBJECT ~= nil),
        tostring(CollisionFlag ~= nil and CollisionFlag.BUILDING ~= nil))
    log("PROBE Washable.getDirtAmount=%s setDirtAmount=%s getIsOnField(Vehicle)=%s",
        tostring(Washable ~= nil and Washable.getDirtAmount ~= nil),
        tostring(Washable ~= nil and Washable.setDirtAmount ~= nil),
        tostring(Vehicle ~= nil and Vehicle.getIsOnField ~= nil))
end

function DirtyMikes.installWashableOverride()
    if DirtyMikes.washableOverrideInstalled then
        return true
    end

    if Washable == nil or Washable.getDirtMultiplier == nil
        or Utils == nil or Utils.overwrittenFunction == nil then
        log("ERROR: Could not install Washable dirt override; required FS25 functions were not found.")
        return false
    end

    DirtyMikes.originalWashableGetDirtMultiplier = Washable.getDirtMultiplier
    Washable.getDirtMultiplier = Utils.overwrittenFunction(
        DirtyMikes.originalWashableGetDirtMultiplier,
        DirtyMikes.getDirtMultiplier
    )
    DirtyMikes.washableOverrideInstalled = true

    log("Override installed. Road 0x, dry field 4x, damp 6x, wet 10x, extremely muddy 12x.")
    return true
end

-- Install at source-load time, before vehicle types copy their functions.
-- (0.2.0.2 log showed the loadMap install was never called: 0 calls.)
DirtyMikes.installWashableOverride()

DirtyMikes.updateTimer = 0
DirtyMikes.reportedCalls = false

function DirtyMikes:update(dt)
    if self.reportedCalls or not self.DEBUG then return end
    self.updateTimer = self.updateTimer + dt
    if self.updateTimer >= 60000 then
        self.reportedCalls = true
        log("CHECK after 60s: override has been called %d times (0 = hook not active).", self.overrideCallCount)
    end
end

function DirtyMikes:loadMap()
    self.installWashableOverride() -- no-op if already installed
    self:probeApi()
    log("v%s loaded. Override installed: %s", self.VERSION, tostring(self.washableOverrideInstalled))
end

function DirtyMikes:deleteMap()
    log("unloaded. Override was called %d times this session.", self.overrideCallCount)
end

addModEventListener(DirtyMikes)
