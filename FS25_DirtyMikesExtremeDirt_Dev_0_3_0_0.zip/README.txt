DIRTY MIKE'S EXTREME DIRT
Farming Simulator 25

Version: 0.3.0.0
Target game version: 1.25.0.0
Developer: Dirty Mike's

DIRT MULTIPLIERS
- Dry roads / off-field: 0x
- Dry fields: 4x
- Damp fields: 6x
- Wet fields: 10x
- Extremely muddy fields: 12x

GROUND-WETNESS BANDS
- Dry: 0.00
- Damp: above 0.00 through 0.25
- Wet: above 0.25 through 0.625
- Extremely muddy: above 0.625

NOTES
- Uses the game's Washable dirt system so normal pressure washing remains available.
- The dirt multiplier override preserves additive contributions from other vehicle specializations where possible.
- Off-field ground is treated as road / non-field and receives 0x base dirt accumulation.
- RAIN CLEANING (0.3.0.0): uncovered vehicles lose 1% dirt every 10 min (light rain), 5 min (medium) or 3 min (heavy). Vehicles with a roof overhead are not cleaned. Needs in-game verification.
- Performance penalties, accelerated wear, and breakdowns are not implemented yet.
- Multiplayer support is not enabled.

DEVELOPMENT STATUS
0.3.0.0 is a development build. ZIP structure and XML are packaged for testing;
new multiplier behavior still requires in-game verification on FS25 1.25.0.0.
