DIRTY MIKE'S EXTREME DIRT
Farming Simulator 25

Version: 0.3.0.1
Target game version: 1.25.0.0 (descVersion 105)
Developer: Dirty Mike's

INSTALL
- Put FS25_DirtyMikesExtremeDirt_Dev_0_3_0_1.zip in your mods folder.
- DELETE any older FS25_DirtyMikesExtremeDirt_Dev_*.zip first. Two versions
  loaded at once would both hook the dirt system.

DIRT MULTIPLIERS
- Dry roads / off-field: 0x
- Dry fields: 4x
- Damp fields: 6x
- Wet fields: 10x
- Extremely muddy fields: 12x

GROUND-WETNESS BANDS
- Dry: 0.00
- Damp: above 0.00 through 0.25
- Wet: above 0.25 through 0.625
- Extremely muddy: above 0.625

RAIN CLEANING
- Vehicles outside lose 1% dirt every 10 min (light rain), 5 min (medium)
  or 3 min (heavy). Minutes are real-time minutes.
- Applies to every vehicle, parked ones included.
- Vehicles with a roof, shed or bridge overhead are NOT cleaned
  (upward raycast from 1 m above the vehicle, 25 m long).
- The game's own rain washing is switched off by this mod. Vanilla rain cleans
  stopped vehicles to 50% in about 10 minutes (even indoors) and makes dirt
  build up 2.5x faster while raining. Pressure washers and wash bays work
  normally.

TEST CONSOLE COMMANDS
Needs the developer console: in Documents\My Games\FarmingSimulator2025\game.xml
set <development><controls>true</controls></development>. In game press the
~ key (twice to get the command line).
- dmStatus          shows hook calls, vehicle counts, rain, cover of your vehicle
- dmRainTest 1      fake heavy rain (0.2 light, 0.5 medium, 1 heavy)
- dmRainTest off    back to real weather
- dmDirt 0.8        set the vehicle you are in to 80% dirt

NOTES
- Uses the game's Washable dirt system so normal pressure washing remains available.
- The dirt multiplier override preserves additive contributions from other vehicle specializations where possible.
- Set DirtyMikes.DEBUG = false in scripts/DirtyMikes.lua to silence log lines.
- Performance penalties, accelerated wear, and breakdowns are not implemented yet.
- Multiplayer support is not enabled.

DEVELOPMENT STATUS
0.3.0.1 is a development build. Rain cleaning and roof detection still need
in-game verification on FS25 1.25.0.0.
