-- Dirty Mike's Extreme Dirt
-- Farming Simulator 25
-- Development Version 0.3.0.1
--
-- Changes in 0.3.0.1 (rain cleaning fix + test tools, multipliers unchanged):
--   * Rain cleaning now runs from the mod's own update loop for EVERY washable
--     vehicle (parked ones too), once per second. In 0.3.0.0 it only ran inside
--     getDirtMultiplier, which the game calls only while that vehicle is ticking.
--   * The game's own (vanilla) rain washing is now blocked. Vanilla washes a
--     stopped vehicle down to 50% in about 10 min of rain, even indoors, and
--     multiplies dirt build-up x2.5 while it rains. Both would override our
--     slower 1%-per-interval rain and our "no rain under a roof" rule.
--   * Roof check rewritten: ray starts 1 m above the vehicle root (low sheds
--     work), 25 m long, mask built with bitOR, tries the FS25 and FS22
--     raycastClosest argument orders and logs which one worked.
--   * New debug lines: COVER (every 15 s for the vehicle you drive), RAIN
--     (throttled), and a CHECK every 5 min that also counts vehicles, so an
--     empty save can't look like a broken hook.
--   * Console commands for testing: dmStatus, dmRainTest, dmDirt.
-- Changes in 0.3.0.0: rain cleaning (1% per 10/5/3 min by rainfall, none under
-- cover; cover = raycast upward). Multipliers unchanged.
-- Changes in 0.2.0.4: fixed debug-line crash ("probe" was declared after use).
-- Changes in 0.2.0.3: override now installs at file load (0.2.0.2 log
-- proved the loadMap install was never called). Adds a 60s CHECK log line.
-- Changes in 0.2.0.2 (diagnostic build, multipliers unchanged):
--   * Throttled debug output for the vehicle you are driving.
--   * One-time API probe at map load. Set DirtyMikes.DEBUG = false to silence.
--
-- Multipliers (unchanged from 0.2.0.1):
--   Dry road / off-field: 0x    Dry field: 4x    Damp: 6x
--   Wet field: 10x              Extremely muddy: 12x

DirtyMikes = {}
DirtyMikes.MOD_NAME = "Dirty Mike's Extreme Dirt"
DirtyMikes.VERSION = "0.3.0.1"
DirtyMikes.DEBUG = true
DirtyMikes.DEBUG_INTERVAL_MS = 5000
DirtyMikes.lastDebugTime = 0
DirtyMikes.overrideCallCount = 0

DirtyMikes.DIRT_MULTIPLIERS = {
    ROAD = 0,
    DRY_FIELD = 4,
    DAMP_FIELD = 6,
    WET_FIELD = 10,
    EXTREMELY_MUDDY_FIELD = 12
}

DirtyMikes.WETNESS_THRESHOLDS = {
    DAMP_MAX = 0.25,
    WET_MAX = 0.625
}

local function log(fmt, ...)
    print(string.format("[%s] " .. fmt, DirtyMikes.MOD_NAME, ...))
end

-- Safe method call: returns value or "n/a"
local function probe(obj, name)
    if obj == nil or obj[name] == nil then return "n/a" end
    local ok, v = pcall(obj[name], obj)
    if not ok then return "err" end
    return v
end

local function vehicleName(vehicle)
    if vehicle ~= nil and vehicle.getName ~= nil then
        local ok, name = pcall(vehicle.getName, vehicle)
        if ok and name ~= nil then return tostring(name) end
    end
    return "vehicle"
end

function DirtyMikes.readIsOnField(vehicle)
    if vehicle.getIsOnField ~= nil then
        return vehicle:getIsOnField() == true, "getIsOnField()"
    elseif vehicle.isOnField ~= nil then
        return vehicle.isOnField == true, "isOnField"
    end
    return false, "NOT FOUND"
end

function DirtyMikes.getWeather()
    local mission = g_currentMission
    return mission and mission.environment and mission.environment.weather
end

function DirtyMikes.readWetness()
    local weather = DirtyMikes.getWeather()
    if weather ~= nil and weather.getGroundWetness ~= nil then
        return weather:getGroundWetness() or 0
    end
    return 0
end

function DirtyMikes.getTargetBaseDirtMultiplier(vehicle)
    local speed = 0
    if vehicle.getLastSpeed ~= nil then
        speed = vehicle:getLastSpeed()
    end
    local onField, fieldSource = DirtyMikes.readIsOnField(vehicle)
    local wetness = DirtyMikes.readWetness()

    local target
    if speed < 1 then
        target = 0
    elseif not onField then
        target = DirtyMikes.DIRT_MULTIPLIERS.ROAD
    elseif wetness <= 0 then
        target = DirtyMikes.DIRT_MULTIPLIERS.DRY_FIELD
    elseif wetness <= DirtyMikes.WETNESS_THRESHOLDS.DAMP_MAX then
        target = DirtyMikes.DIRT_MULTIPLIERS.DAMP_FIELD
    elseif wetness <= DirtyMikes.WETNESS_THRESHOLDS.WET_MAX then
        target = DirtyMikes.DIRT_MULTIPLIERS.WET_FIELD
    else
        target = DirtyMikes.DIRT_MULTIPLIERS.EXTREMELY_MUDDY_FIELD
    end

    return target, speed, onField, fieldSource, wetness
end

-- ---------------------------------------------------------------------
-- Helpers: vehicle list, controlled vehicle, server check
-- ---------------------------------------------------------------------
function DirtyMikes.getVehicleList()
    local mission = g_currentMission
    if mission == nil then return {}, "no mission" end
    if mission.vehicleSystem ~= nil and mission.vehicleSystem.vehicles ~= nil then
        return mission.vehicleSystem.vehicles, "vehicleSystem.vehicles"
    end
    if mission.vehicles ~= nil then
        return mission.vehicles, "mission.vehicles"
    end
    return {}, "NOT FOUND"
end

function DirtyMikes.getControlledVehicle()
    if g_localPlayer ~= nil and g_localPlayer.getCurrentVehicle ~= nil then
        local ok, v = pcall(g_localPlayer.getCurrentVehicle, g_localPlayer)
        if ok and v ~= nil then return v end
    end
    local mission = g_currentMission
    if mission ~= nil and mission.controlledVehicle ~= nil then
        return mission.controlledVehicle
    end
    return nil
end

function DirtyMikes.getIsServer()
    local mission = g_currentMission
    if mission ~= nil and mission.getIsServer ~= nil then
        return mission:getIsServer()
    end
    return true -- single player is always the server
end

-- ---------------------------------------------------------------------
-- Rain cleaning
--   Uncovered vehicles lose 1% dirt every N minutes (real time) while it rains:
--     light rain  (rain scale <= 0.33): every 10 min
--     medium rain (<= 0.66):            every 5 min
--     heavy rain  (> 0.66):             every 3 min
--   Vehicles with something solid overhead (shed, roof, bridge) are not cleaned.
--   Runs once per second from DirtyMikes:update for every washable vehicle.
-- ---------------------------------------------------------------------
DirtyMikes.RAIN = {
    ENABLED = true,
    BLOCK_VANILLA_RAIN_WASH = true,
    MIN_RAIN = 0.01,
    LIGHT_MAX = 0.33,
    MEDIUM_MAX = 0.66,
    STEP = 0.01,               -- 1% dirt
    LIGHT_MINUTES = 10,
    MEDIUM_MINUTES = 5,
    HEAVY_MINUTES = 3,
    APPLY_THRESHOLD = 0.002,   -- apply cleaning in chunks of 0.2%
    UPDATE_INTERVAL_MS = 1000, -- how often the rain loop runs
    MAX_DT_MS = 5000,          -- ignore larger gaps (pause, loading)
    COVER_START_OFFSET = 1.0,  -- metres above the vehicle root where the ray starts
    COVER_RAY_LENGTH = 25,     -- metres checked above that point
    COVER_CACHE_MS = 5000,
    COVER_DEBUG_INTERVAL_MS = 15000,
    MAX_LOG_LINES = 200
}
DirtyMikes.rainLogLines = 0
DirtyMikes.rainTimer = 0
DirtyMikes.rainTestScale = nil  -- set by console command dmRainTest
DirtyMikes.lastCoverDebugTime = 0
DirtyMikes.vanillaRainBlockedCount = 0

function DirtyMikes.getRainIntervalMinutes(rain)
    local r = DirtyMikes.RAIN
    if rain <= r.MIN_RAIN then
        return nil
    elseif rain <= r.LIGHT_MAX then
        return r.LIGHT_MINUTES
    elseif rain <= r.MEDIUM_MAX then
        return r.MEDIUM_MINUTES
    end
    return r.HEAVY_MINUTES
end

-- Returns rain scale (0..1) and a label for where it came from
function DirtyMikes.readRain()
    if DirtyMikes.rainTestScale ~= nil then
        return DirtyMikes.rainTestScale, "TEST (dmRainTest)"
    end
    local weather = DirtyMikes.getWeather()
    if weather ~= nil and weather.getRainFallScale ~= nil then
        return weather:getRainFallScale() or 0, "weather"
    end
    return 0, "no weather"
end

-- Build collision mask once (STATIC_OBJECT + BUILDING + STATIC_WORLD)
function DirtyMikes.getCoverMask()
    if DirtyMikes.coverMask ~= nil then return DirtyMikes.coverMask end
    local mask = 0
    if CollisionFlag ~= nil then
        for _, name in ipairs({"STATIC_OBJECT", "BUILDING", "STATIC_WORLD"}) do
            local flag = CollisionFlag[name]
            if flag ~= nil then
                if bitOR ~= nil then
                    mask = bitOR(mask, flag)
                else
                    mask = mask + flag -- fallback; may double-count shared bits
                end
            end
        end
    end
    DirtyMikes.coverMask = mask
    log("COVER mask=%d (bitOR=%s)", mask, tostring(bitOR ~= nil))
    return mask
end

-- Raycast callback (called by the engine with the object that was hit)
function DirtyMikes:coverRayCallback(hitObjectId, x, y, z, distance)
    if hitObjectId ~= nil and hitObjectId ~= 0 then
        self.coverHit = true
        self.coverHitDistance = distance
        return false -- stop at first hit
    end
    return true
end

-- Two possible argument orders. "FS25" puts maxDistance before the callback name,
-- "FS22" puts the callback name first. We try the remembered one, then the other.
local function castUp(sig, x, y, z, length, mask)
    if sig == "FS25" then
        raycastClosest(x, y, z, 0, 1, 0, length, "coverRayCallback", DirtyMikes, mask)
    else
        raycastClosest(x, y, z, 0, 1, 0, "coverRayCallback", length, DirtyMikes, mask)
    end
end

-- Returns covered (bool), source label
function DirtyMikes.isVehicleCovered(vehicle, ignoreCache)
    local r = DirtyMikes.RAIN
    local now = g_time or 0
    if not ignoreCache and vehicle.dmCoverTime ~= nil and now - vehicle.dmCoverTime < r.COVER_CACHE_MS then
        return vehicle.dmCovered, vehicle.dmCoverSource or "cached"
    end

    local covered, source = false, "no raycast available"
    local mask = DirtyMikes.getCoverMask()
    if raycastClosest ~= nil and getWorldTranslation ~= nil and vehicle.rootNode ~= nil and mask > 0 then
        local x, y, z = getWorldTranslation(vehicle.rootNode)
        local startY = y + r.COVER_START_OFFSET
        local order = {"FS25", "FS22"}
        if DirtyMikes.raySig == "FS22" then order = {"FS22", "FS25"} end

        local lastErr
        for _, sig in ipairs(order) do
            DirtyMikes.coverHit = false
            DirtyMikes.coverHitDistance = nil
            local ok, err = pcall(castUp, sig, x, startY, z, r.COVER_RAY_LENGTH, mask)
            if ok then
                if DirtyMikes.raySig ~= sig then
                    DirtyMikes.raySig = sig
                    log("COVER raycastClosest works with %s argument order", sig)
                end
                covered = DirtyMikes.coverHit == true
                if covered then
                    source = string.format("roof hit %.1fm above", (DirtyMikes.coverHitDistance or -1) + r.COVER_START_OFFSET)
                else
                    source = "clear sky"
                end
                lastErr = nil
                break
            end
            lastErr = err
        end
        if lastErr ~= nil then
            source = "raycast error: " .. tostring(lastErr)
            if not DirtyMikes.rayErrorLogged then
                DirtyMikes.rayErrorLogged = true
                log("ERROR: raycastClosest failed with both argument orders: %s", tostring(lastErr))
            end
        end
    end

    vehicle.dmCovered = covered
    vehicle.dmCoverSource = source
    vehicle.dmCoverTime = now
    return covered, source
end

function DirtyMikes.applyRainCleaning(vehicle, rain, rainSource)
    local r = DirtyMikes.RAIN
    if vehicle.getDirtAmount == nil or vehicle.addDirtAmount == nil then return end

    local last = vehicle.dmRainLastTime
    vehicle.dmRainLastTime = g_time
    if last == nil then return end
    local dt = g_time - last
    if dt <= 0 then return end
    if dt > r.MAX_DT_MS then dt = r.MAX_DT_MS end

    local minutes = DirtyMikes.getRainIntervalMinutes(rain)
    if minutes == nil then
        vehicle.dmRainPending = 0
        return
    end

    vehicle.dmRainPending = (vehicle.dmRainPending or 0) + dt * (r.STEP / (minutes * 60000))
    if vehicle.dmRainPending < r.APPLY_THRESHOLD then return end

    local amount = vehicle.dmRainPending
    vehicle.dmRainPending = 0

    local dirtBefore = vehicle:getDirtAmount()
    if dirtBefore == nil or dirtBefore <= 0 then return end

    local covered, source = DirtyMikes.isVehicleCovered(vehicle)
    if not covered then
        vehicle:addDirtAmount(-math.min(amount, dirtBefore))
    end

    if DirtyMikes.DEBUG and DirtyMikes.rainLogLines < r.MAX_LOG_LINES then
        DirtyMikes.rainLogLines = DirtyMikes.rainLogLines + 1
        log("RAIN %s rain=%.2f (%s) every=%dmin covered=%s (%s) cleaned=%s dirt %.1f%% -> %.1f%%",
            vehicleName(vehicle), rain, rainSource, minutes, tostring(covered), source,
            tostring(not covered), dirtBefore * 100, (vehicle:getDirtAmount() or 0) * 100)
        if DirtyMikes.rainLogLines == r.MAX_LOG_LINES then
            log("RAIN log limit reached (%d lines); further RAIN lines are silenced.", r.MAX_LOG_LINES)
        end
    end
end

-- Runs every RAIN.UPDATE_INTERVAL_MS from DirtyMikes:update
function DirtyMikes.rainTick()
    local r = DirtyMikes.RAIN
    if not r.ENABLED or g_time == nil or not DirtyMikes.getIsServer() then return end

    local rain, rainSource = DirtyMikes.readRain()
    local vehicles = DirtyMikes.getVehicleList()
    for _, vehicle in pairs(vehicles) do
        if type(vehicle) == "table" and vehicle.spec_washable ~= nil then
            local ok, err = pcall(DirtyMikes.applyRainCleaning, vehicle, rain, rainSource)
            if not ok and not DirtyMikes.rainErrorLogged then
                DirtyMikes.rainErrorLogged = true
                log("ERROR in rain cleaning (%s): %s", vehicleName(vehicle), tostring(err))
            end
        end
    end
end

-- Logs the roof check for the vehicle you are driving, rain or not, so cover
-- detection can be tested in dry weather.
function DirtyMikes.coverDebugTick()
    if not DirtyMikes.DEBUG or g_time == nil then return end
    if g_time - DirtyMikes.lastCoverDebugTime < DirtyMikes.RAIN.COVER_DEBUG_INTERVAL_MS then return end
    local vehicle = DirtyMikes.getControlledVehicle()
    if vehicle == nil or vehicle.spec_washable == nil then return end
    DirtyMikes.lastCoverDebugTime = g_time
    local covered, source = DirtyMikes.isVehicleCovered(vehicle, true)
    local rain, rainSource = DirtyMikes.readRain()
    log("COVER %s covered=%s (%s) | rain=%.2f (%s) dirt=%.1f%%",
        vehicleName(vehicle), tostring(covered), source, rain, rainSource,
        (vehicle.getDirtAmount ~= nil and vehicle:getDirtAmount() or 0) * 100)
end

-- ---------------------------------------------------------------------
-- Overrides
-- ---------------------------------------------------------------------
-- Called as: newFunc(vehicle, superFunc) via Utils.overwrittenFunction
function DirtyMikes.getDirtMultiplier(vehicle, superFunc)
    local combined = superFunc(vehicle)
    local original = DirtyMikes.originalWashableGetDirtMultiplier(vehicle)
    local target, speed, onField, fieldSource, wetness = DirtyMikes.getTargetBaseDirtMultiplier(vehicle)
    local result = combined + target - original

    DirtyMikes.overrideCallCount = DirtyMikes.overrideCallCount + 1

    if DirtyMikes.DEBUG and g_time ~= nil
        and vehicle.getIsControlled ~= nil and vehicle:getIsControlled()
        and g_time - DirtyMikes.lastDebugTime >= DirtyMikes.DEBUG_INTERVAL_MS then
        DirtyMikes.lastDebugTime = g_time
        log("DEBUG speed=%.1f km/h onField=%s (via %s) wetness=%.3f rain=%s dirt=%s | vanilla=%.2f target=%.2f combined=%.2f -> result=%.2f | calls=%d",
            speed, tostring(onField), fieldSource, wetness, tostring(probe(DirtyMikes.getWeather(), "getRainFallScale")),
            tostring(probe(vehicle, "getDirtAmount")), original, target, combined, result,
            DirtyMikes.overrideCallCount)
    end

    return result
end

-- Blocks vanilla rain washing (it would clean indoors and much faster than ours).
-- Pressure washer and wash triggers are untouched.
function DirtyMikes.getAllowsWashingByType(vehicle, superFunc, washType)
    if DirtyMikes.RAIN.BLOCK_VANILLA_RAIN_WASH and Washable.WASHTYPE_RAIN ~= nil
        and washType == Washable.WASHTYPE_RAIN then
        DirtyMikes.vanillaRainBlockedCount = DirtyMikes.vanillaRainBlockedCount + 1
        return false
    end
    return superFunc(vehicle, washType)
end

function DirtyMikes:probeApi()
    if not DirtyMikes.DEBUG then return end
    local w = DirtyMikes.getWeather()
    local _, listSource = DirtyMikes.getVehicleList()
    log("PROBE weather=%s getRainFallScale=%s getGroundWetness=%s",
        tostring(w ~= nil), tostring(w ~= nil and w.getRainFallScale ~= nil), tostring(w ~= nil and w.getGroundWetness ~= nil))
    log("PROBE addDirtAmount=%s raycastClosest=%s bitOR=%s CollisionFlag=%s STATIC_OBJECT=%s BUILDING=%s STATIC_WORLD=%s",
        tostring(Washable ~= nil and Washable.addDirtAmount ~= nil), tostring(raycastClosest ~= nil), tostring(bitOR ~= nil),
        tostring(CollisionFlag ~= nil),
        tostring(CollisionFlag ~= nil and CollisionFlag.STATIC_OBJECT),
        tostring(CollisionFlag ~= nil and CollisionFlag.BUILDING),
        tostring(CollisionFlag ~= nil and CollisionFlag.STATIC_WORLD))
    log("PROBE Washable.getDirtAmount=%s WASHTYPE_RAIN=%s vehicleList=%s g_localPlayer=%s addConsoleCommand=%s",
        tostring(Washable ~= nil and Washable.getDirtAmount ~= nil),
        tostring(Washable ~= nil and Washable.WASHTYPE_RAIN),
        listSource, tostring(g_localPlayer ~= nil), tostring(addConsoleCommand ~= nil))
end

function DirtyMikes.installWashableOverride()
    if DirtyMikes.washableOverrideInstalled then
        return true
    end

    if Washable == nil or Washable.getDirtMultiplier == nil
        or Utils == nil or Utils.overwrittenFunction == nil then
        log("ERROR: Could not install Washable dirt override; required FS25 functions were not found.")
        return false
    end

    DirtyMikes.originalWashableGetDirtMultiplier = Washable.getDirtMultiplier
    Washable.getDirtMultiplier = Utils.overwrittenFunction(
        DirtyMikes.originalWashableGetDirtMultiplier,
        DirtyMikes.getDirtMultiplier
    )
    DirtyMikes.washableOverrideInstalled = true
    log("Override installed. Road 0x, dry field 4x, damp 6x, wet 10x, extremely muddy 12x.")

    if Washable.getAllowsWashingByType ~= nil then
        Washable.getAllowsWashingByType = Utils.overwrittenFunction(
            Washable.getAllowsWashingByType,
            DirtyMikes.getAllowsWashingByType
        )
        DirtyMikes.rainBlockInstalled = true
        log("Vanilla rain washing blocked (mod handles rain). Pressure washing unchanged.")
    else
        log("WARNING: Washable.getAllowsWashingByType not found; vanilla rain washing stays active.")
    end
    return true
end

-- Install at source-load time, before vehicle types copy their functions.
-- (0.2.0.2 log showed the loadMap install was never called: 0 calls.)
DirtyMikes.installWashableOverride()

-- ---------------------------------------------------------------------
-- Console commands (need developer console, see README)
-- ---------------------------------------------------------------------
function DirtyMikes:consoleStatus()
    local vehicles, listSource = DirtyMikes.getVehicleList()
    local total, washable = 0, 0
    for _, v in pairs(vehicles) do
        total = total + 1
        if type(v) == "table" and v.spec_washable ~= nil then washable = washable + 1 end
    end
    local rain, rainSource = DirtyMikes.readRain()
    local msg = string.format("v%s calls=%d vehicles=%d washable=%d (%s) rain=%.2f (%s) vanillaRainBlocked=%d raySig=%s",
        DirtyMikes.VERSION, DirtyMikes.overrideCallCount, total, washable, listSource,
        rain, rainSource, DirtyMikes.vanillaRainBlockedCount, tostring(DirtyMikes.raySig))
    log("STATUS %s", msg)
    local vehicle = DirtyMikes.getControlledVehicle()
    if vehicle ~= nil and vehicle.spec_washable ~= nil then
        local covered, source = DirtyMikes.isVehicleCovered(vehicle, true)
        log("STATUS %s dirt=%.1f%% covered=%s (%s)", vehicleName(vehicle),
            (vehicle:getDirtAmount() or 0) * 100, tostring(covered), source)
    end
    return msg
end

function DirtyMikes:consoleRainTest(value)
    if value == nil or value == "" or value == "off" then
        DirtyMikes.rainTestScale = nil
        log("TEST rain override OFF (real weather used)")
        return "Rain test off"
    end
    local scale = tonumber(value)
    if scale == nil then return "Usage: dmRainTest <0..1|off>" end
    scale = math.max(0, math.min(1, scale))
    DirtyMikes.rainTestScale = scale
    log("TEST rain override ON: rain=%.2f -> every %s min", scale,
        tostring(DirtyMikes.getRainIntervalMinutes(scale) or "never"))
    return string.format("Rain test set to %.2f", scale)
end

function DirtyMikes:consoleDirt(value)
    local vehicle = DirtyMikes.getControlledVehicle()
    if vehicle == nil or vehicle.setDirtAmount == nil then return "Get in a vehicle first" end
    local amount = tonumber(value)
    if amount == nil then return "Usage: dmDirt <0..1>" end
    amount = math.max(0, math.min(1, amount))
    vehicle:setDirtAmount(amount, true)
    log("TEST set %s dirt to %.1f%%", vehicleName(vehicle), amount * 100)
    return string.format("Dirt set to %.0f%%", amount * 100)
end

function DirtyMikes.registerConsoleCommands()
    if addConsoleCommand == nil or DirtyMikes.consoleRegistered then return end
    local ok, err = pcall(function()
        addConsoleCommand("dmStatus", "Dirty Mike's: show mod status", "consoleStatus", DirtyMikes)
        addConsoleCommand("dmRainTest", "Dirty Mike's: fake rain 0..1 or off", "consoleRainTest", DirtyMikes)
        addConsoleCommand("dmDirt", "Dirty Mike's: set current vehicle dirt 0..1", "consoleDirt", DirtyMikes)
    end)
    DirtyMikes.consoleRegistered = ok
    log("Console commands registered: %s%s", tostring(ok), ok and "" or (" (" .. tostring(err) .. ")"))
end

-- ---------------------------------------------------------------------
-- Mod event listener
-- ---------------------------------------------------------------------
DirtyMikes.checkTimer = 0
DirtyMikes.CHECK_INTERVAL_MS = 300000 -- 5 min
DirtyMikes.firstCheckDone = false

function DirtyMikes:update(dt)
    local ok, err = pcall(function()
        self.rainTimer = self.rainTimer + dt
        if self.rainTimer >= self.RAIN.UPDATE_INTERVAL_MS then
            self.rainTimer = 0
            self.rainTick()
        end
        self.coverDebugTick()

        if self.DEBUG then
            self.checkTimer = self.checkTimer + dt
            local due = (not self.firstCheckDone and self.checkTimer >= 60000) or self.checkTimer >= self.CHECK_INTERVAL_MS
            if due then
                self.firstCheckDone = true
                self.checkTimer = 0
                local vehicles = self.getVehicleList()
                local washable = 0
                for _, v in pairs(vehicles) do
                    if type(v) == "table" and v.spec_washable ~= nil then washable = washable + 1 end
                end
                log("CHECK override calls=%d, washable vehicles=%d, vanilla rain blocks=%d%s",
                    self.overrideCallCount, washable, self.vanillaRainBlockedCount,
                    (washable == 0) and " (no vehicles yet: 0 calls is expected)" or "")
            end
        end
    end)
    if not ok and not self.updateErrorLogged then
        self.updateErrorLogged = true
        log("ERROR in update: %s", tostring(err))
    end
end

function DirtyMikes:loadMap()
    self.installWashableOverride() -- no-op if already installed
    self:probeApi()
    self.registerConsoleCommands()
    log("v%s loaded. Override installed: %s, rain block installed: %s",
        self.VERSION, tostring(self.washableOverrideInstalled), tostring(self.rainBlockInstalled == true))
end

function DirtyMikes:deleteMap()
    if self.consoleRegistered and removeConsoleCommand ~= nil then
        pcall(removeConsoleCommand, "dmStatus")
        pcall(removeConsoleCommand, "dmRainTest")
        pcall(removeConsoleCommand, "dmDirt")
        self.consoleRegistered = false
    end
    log("unloaded. Override was called %d times this session.", self.overrideCallCount)
end

addModEventListener(DirtyMikes)
